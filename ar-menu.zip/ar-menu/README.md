# 🍽️ AR Menu — Web AR Restaurant Menu Card

A **premium, production-ready Web AR restaurant menu** built entirely as a static site.  
Customers scan a QR code, browse your menu, and view dishes in **3D / Augmented Reality** — all from their phone browser.  
No app install needed. Hosted free on GitHub Pages.

---

## ✨ Features

- 🎨 Dark luxury glassmorphism design
- 📱 Mobile-first, fully responsive
- 🔍 Search, category, and veg/non-veg filters
- 🧊 3D dish models with `<model-viewer>` (Google's WebXR library)
- 🕶️ AR support: Scene Viewer (Android), Quick Look (iOS), WebXR
- 🛠️ Admin panel to add/edit/delete dishes (no code needed)
- 📤 Export updated `menu.json` to replace on GitHub
- 📲 Auto QR code generation from deployed URL

---

## 📁 Folder Structure

```
ar-menu/
├── index.html          ← Public menu (share this URL)
├── admin.html          ← Admin panel (password protect via GitHub)
├── css/
│   ├── style.css       ← Main styles
│   ├── admin.css       ← Admin styles
│   └── animations.css  ← Keyframes and reveal animations
├── js/
│   ├── app.js          ← Menu page logic
│   ├── admin.js        ← Admin panel logic
│   ├── data.js         ← Data layer (localStorage + menu.json)
│   ├── ui.js           ← Reusable UI components
│   └── qr.js           ← QR code generation
├── data/
│   └── menu.json       ← ⭐ YOUR MAIN DATA FILE — edit this!
├── assets/
│   ├── logo.png        ← Hotel logo (replace this)
│   └── logo.svg        ← SVG fallback logo
├── models/
│   └── dish-name/      ← One folder per dish
│       ├── model.glb   ← 3D model for Android / WebXR
│       ├── model.usdz  ← 3D model for iPhone (optional)
│       └── poster.jpg  ← Preview thumbnail image
└── README.md
```

---

## 🚀 Deploying to GitHub Pages (Step by Step)

### Step 1 — Upload to GitHub

1. Go to [github.com](https://github.com) and log in (or create a free account)
2. Click **New Repository**
3. Name it: `ar-menu` (or anything you like)
4. Choose **Public** (required for free GitHub Pages)
5. Click **Create repository**
6. Upload all files by clicking **"uploading an existing file"**
7. Drag and drop the entire `ar-menu` folder contents
8. Click **Commit changes**

### Step 2 — Enable GitHub Pages

1. In your repository, click **Settings** tab
2. Scroll to **Pages** in the left sidebar
3. Under "Source" → select **main branch** → **/ (root)**
4. Click **Save**
5. Wait 2–3 minutes — your URL will appear:  
   `https://YOUR-USERNAME.github.io/ar-menu`

### Step 3 — Done!

Visit your URL and your AR menu is live. Share it or use the QR code!

---

## ✏️ How to Update Your Menu

### Option A — Admin Panel (Easiest)

1. Open `https://YOUR-USERNAME.github.io/ar-menu/admin.html`
2. Add/edit/delete dishes as needed
3. Changes are saved in the browser's local storage (only on your device)
4. Click **Export JSON** to download an updated `menu.json`
5. Upload the new `menu.json` to the `/data/` folder on GitHub
6. All customers will see the updated menu!

### Option B — Edit menu.json Directly

1. Open `data/menu.json` in GitHub
2. Click the pencil (edit) icon
3. Update the dish info
4. Click **Commit changes**

---

## 🧊 How to Add a 3D Model

### Step 1 — Get the model

You need a `.glb` file (Android + WebXR) and optionally a `.usdz` (iPhone).

**Free 3D model sources:**
- [Sketchfab](https://sketchfab.com) — Search for food models, filter "Downloadable"
- [Google Poly Archive](https://github.com/nicktindall/cyclopedia) — archived 3D assets
- [Turbosquid](https://www.turbosquid.com/Search/3D-Models/free/food) — free food models
- Hire a 3D artist on Fiverr

**Recommended model specs:**
- Polygon count: Under 50,000 triangles
- Texture size: 1024×1024 or 2048×2048 max
- File size: Under 5MB (ideally under 2MB for fast loading)
- Format: `.glb` (self-contained, includes textures)

### Step 2 — Create folder and upload

1. In your GitHub repository, create a folder:  
   `models/your-dish-name/`
2. Upload files:
   - `model.glb`
   - `model.usdz` (optional, for iPhone Quick Look)
   - `poster.jpg` (thumbnail shown while 3D loads)

### Step 3 — Update menu.json

```json
{
  "id": "dish-009",
  "name": "Your Dish Name",
  "price": 350,
  "description": "Description of the dish",
  "type": "veg",
  "category": "Starters",
  "modelGlb": "models/your-dish-name/model.glb",
  "modelUsdz": "models/your-dish-name/model.usdz",
  "thumbnail": "models/your-dish-name/poster.jpg",
  "featured": false
}
```

---

## 🏨 How to Customize Hotel Info

Edit the `"hotel"` section in `data/menu.json`:

```json
"hotel": {
  "name": "YOUR HOTEL NAME",
  "logo": "assets/logo.png",
  "description": "Your tagline or description",
  "address": "Your address",
  "phone": "+91 XXXXX XXXXX",
  "email": "your@email.com"
}
```

Replace `assets/logo.png` with your actual logo file.

---

## 📲 AR Compatibility

| Device | AR Mode |
|--------|---------|
| Android (Chrome) | Scene Viewer (native AR) |
| iPhone (Safari) | Quick Look (AR) |
| Desktop (Chrome/Edge) | WebXR if device supports it |
| Other browsers | 3D viewer (no AR, but 3D works) |

The `<model-viewer>` component automatically detects AR support and shows the AR button only when available. On unsupported devices, the 3D model is still visible and interactive.

---

## 🔐 Securing the Admin Panel

Since GitHub Pages is public, anyone could find `/admin.html`.  
To protect it:

**Option 1 — Rename the admin URL:**  
Rename `admin.html` to something obscure like `mgr-a7x2.html` and don't share that URL.

**Option 2 — Add a simple password check:**  
Add this to the top of `admin.html` inside `<script>`:
```js
const pass = prompt("Enter admin password:");
if (pass !== "your-secret-password") {
  window.location.href = "index.html";
}
```

**Option 3 — Use GitHub repository visibility:**  
Keep the repository private. Use [Cloudflare Pages](https://pages.cloudflare.com/) (free) for private repo hosting.

---

## 💡 Tips & Best Practices

- **Logo**: Use a PNG with transparent background, 200×60px or similar
- **Thumbnails**: 600×450px JPG, optimized with [Squoosh](https://squoosh.app)
- **3D models**: Compress with [gltf-transform](https://gltf-transform.donmccurdy.com/)
- **Menu updates**: Always export and re-upload `menu.json` after admin edits so other devices see changes
- **Testing AR**: Use a real Android or iPhone — AR does not work on desktop browsers

---

## 🔮 Future Upgrade Ideas

- Add ordering / cart system (requires Supabase or Firebase)
- Password-protected admin with Netlify Identity
- Multi-language support
- Table QR codes with table number tracking
- Allergen / calorie info per dish
- Daily specials section
- Custom domain (`menu.yourhotel.com`)

---

## 📞 Support

This project is fully open source. Edit freely.  
For custom development: reach out to your developer with this README.

---

*Built with ❤️ using `<model-viewer>`, vanilla JS, and pure CSS.*
